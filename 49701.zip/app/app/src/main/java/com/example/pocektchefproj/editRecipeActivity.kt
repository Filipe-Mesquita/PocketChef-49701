package com.example.pocektchefproj

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.room.Room
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

//Array auxiliar para guardar os Ids dos layouts do nome e quantidade de cada Ingradiente
var ingIds2 = arrayListOf<Int>()

class editRecipeActivity : AppCompatActivity() {
    //Na criação da Activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_edit_recipe)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Armazenamento dos valores passados por Intent
        //Como depois desta Activity voltaremos para a "RandRecipeActivity" temos que manter o valor de "prevPage",
        // por isso, apesar de não o utilizarmos nesta Activity, temos que o receber via Intent
        val prevPage = intent.getStringExtra("PREV_PAGE")
        val rId = intent.getIntExtra("FOOD_ID", 0)
        val rType = intent.getIntExtra("FOOD_TYPE", 1)
        val rTitle = intent.getStringExtra("FOOD_TITLE")
        val rIngs = intent.getStringExtra("FOOD_INGS")
        val rInst = intent.getStringExtra("FOOD_INST")

        //Referências aos elementos do .xml
        val backBtn5 = findViewById<ImageButton>(R.id.backBTN5)
        val meatCheckBox2 = findViewById<CheckBox>(R.id.meatCB2)
        val fishCheckBox2 = findViewById<CheckBox>(R.id.fishCB2)
        val vegetarianCheckBox2 = findViewById<CheckBox>(R.id.vegetarianCB2)
        val nameInputLayout2 = findViewById<TextInputLayout>(R.id.nameTextInputLT2)
        val nameInput2 = findViewById<TextInputEditText>(R.id.nameTXTInput2)
        val ingListLayout2 = findViewById<LinearLayout>(R.id.ingLT2)
        val addIngBtn2 = findViewById<ImageButton>(R.id.addIngBTN2)
        val instructionsInputLayout2 = findViewById<TextInputLayout>(R.id.instructionsTextInputLT2)
        val instructionsInput2 = findViewById<TextInputEditText>(R.id.instructionsTXTInput2)
        val comitBtn = findViewById<Button>(R.id.comitBTN)

        //backBtn5 clicado -> trocar de activity passando os parâmetros originais da receita que estava a ser editada
        backBtn5.setOnClickListener()
        {
            val intent = Intent(this, RandRecipeActivity::class.java)
            intent.putExtra("PREV_PAGE", prevPage)
            intent.putExtra("FOOD_ID", rId)
            intent.putExtra("FOOD_TYPE", rType)
            intent.putExtra("FOOD_TITLE", rTitle)
            intent.putExtra("FOOD_INGS", rIngs)
            intent.putExtra("FOOD_INST", rInst)
            startActivity(intent)

            //Termina a activity atual
            finish()
        }

        //Colocar o tipo selecionado de acordo com as informações originais da receita
        when (rType)
        {
            1 -> meatCheckBox2.isChecked = true
            2 -> fishCheckBox2.isChecked = true
            3 -> vegetarianCheckBox2.isChecked = true
        }

        //Apenas uma CheckBox pode estar "checked"
        //Caso uma nova seja "checked" a antiga deixa de estar
        meatCheckBox2.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                fishCheckBox2.isChecked = false
                vegetarianCheckBox2.isChecked = false
            }
        }
        fishCheckBox2.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                meatCheckBox2.isChecked = false
                vegetarianCheckBox2.isChecked = false
            }
        }
        vegetarianCheckBox2.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                meatCheckBox2.isChecked = false
                fishCheckBox2.isChecked = false
            }
        }


        //Colocar o nome original da receita no layout de Input
        nameInput2.setText(rTitle)

        //Caso o layout esteja selecionado ou tenha alguma coisa escrita  pelo user este deixa de ter hint
        //Caso volte a estar vazio e sem estar selecionado a hint volta a aparecer
        nameInput2.setOnFocusChangeListener{ _, hasFocus ->
            if (hasFocus) {
                // Hide hint when the field is focused
                nameInputLayout2.hint = null
            } else {
                // Show hint only if field is empty and not focused
                if (nameInput2.text.isNullOrEmpty()) {
                    nameInputLayout2.hint = "Write here the recipe's name"
                }
            }
        }

        //Colocar as instruções originais da receita no layout de Input
        instructionsInput2.setText(rInst)

        //Caso o layout esteja selecionado ou tenha alguma coisa escrita  pelo user este deixa de ter hint
        //Caso volte a estar vazio e sem estar selecionado a hint volta a aparecer
        instructionsInput2.setOnFocusChangeListener{ _, hasFocus ->
            if (hasFocus) {
                // Hide hint when the field is focused
                instructionsInputLayout2.hint = null
            } else {
                // Show hint only if field is empty and not focused
                if (instructionsInput2.text.isNullOrEmpty()) {
                    instructionsInputLayout2.hint = "Write here the recipe's instructions"
                }
            }
        }


        //Split da String com ingredientes que vei da Base de Dados
        //Isto separa os ingreientes e as respetivas quantidades em strings separadas numa List<String>
        //O formato da lista é - ["ing1","qtding1","ing2","qtdIng2","ing3",...]
        val rIngsList = rIngs?.split(";")
        populateIngredients(rIngsList, ingListLayout2)

        //addIngBtn2 clicado -> Adicionar nova linha de input de ingrediente
        addIngBtn2.setOnClickListener()
        {
            addIngredient(ingListLayout2)
        }

        //comitBtn clicado -> verificar se todos os campos estão preenchidos, caso estejam chama a função que atualiza a receita à Base de Dados e troca de Activity passando
        //os parâmetros atualizados da receita, caso contrário aparece um toast com uma mensagem de aviso
        comitBtn.setOnClickListener()
        {
            //cria uma corrotina
            CoroutineScope(Dispatchers.IO).launch{
                if(nameInput2 == null || (!meatCheckBox2.isChecked && !fishCheckBox2.isChecked &&!vegetarianCheckBox2.isChecked) || instructionsInput2 == null || ingIds2.isEmpty())
                {
                    //Passa a executar na main Thread
                    withContext(Dispatchers.Main)
                    {
                        //Cria um toast
                        Toast.makeText(this@editRecipeActivity, "Please fill every field", Toast.LENGTH_SHORT).show()
                    }
                }
                else
                {
                    updateRecipe(rId, nameInput2, meatCheckBox2, fishCheckBox2, vegetarianCheckBox2, instructionsInput2)

                    //Referência à Base de Dados e ao DAO
                    val db = Room.databaseBuilder(
                        applicationContext,
                        ReceitasDatabase::class.java, "database_receitas"
                    ).build()
                    val receitasDao = db.receitasDao()

                    //Querry à Base de Dados da receita com o Id especificado
                    val r = receitasDao.getById(rId)

                    //Passa a executar na main Thread
                    withContext(Dispatchers.Main)
                    {
                        //Cria um toast
                        Toast.makeText(this@editRecipeActivity, "Recipe edited successfully", Toast.LENGTH_SHORT).show()

                        val intent = Intent(this@editRecipeActivity, RandRecipeActivity::class.java)
                        intent.putExtra("PREV_PAGE", prevPage)
                        intent.putExtra("FOOD_ID", r.id)
                        intent.putExtra("FOOD_TYPE", r.tipo)
                        intent.putExtra("FOOD_TITLE", r.nome)
                        intent.putExtra("FOOD_INGS", r.ingredientes)
                        intent.putExtra("FOOD_INST", r.instrucoes)
                        startActivity(intent)

                        //Termina a activity atual
                        finish()
                    }
                }
            }
        }


    }

    //Recebe uma lista com todas os ingredientes e respetivas quantidades e coloca cada um no Parent LinearLayout dado
    //Por cada Input Layout  de nome e quantidade criado é lhe atribuido um Id e este é adicionado ao array de Ids
    private fun populateIngredients(ingList: List<String>?, ingListLayout: LinearLayout) {
        var i = 0
        //Garante que a lista de ingredientes não é nula
        if (ingList != null) {
            for (n in 0 until ingList.size / 2) {       // apenas iteramos n/2 vezes, sendo n o tamanho da lista de ingredients porque a cada iteração vamos acessar dois elementos da lista

                //LinearLayout Horizontal que vai conter os elementos
                val ingredientLayout = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                }

                //Botão para apagar ingredientes
                val deleteIngBtn = ImageButton(this).apply {
                    layoutParams = LinearLayout.LayoutParams(45.dpToPx(context), 45.dpToPx(context)).apply {
                        gravity = Gravity.END
                    }
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setImageResource(R.drawable.delete)

                    val outValue = TypedValue()
                    context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, outValue, true)
                    setBackgroundResource(outValue.resourceId)
                }

                //Image que aparece antes do nome
                val imageView1 = ImageView(this).apply {
                    layoutParams =
                        LinearLayout.LayoutParams(15.dpToPx(context), 10.dpToPx(context))
                            .apply {
                                setMargins(30, 0, 0, 0) // Set margins
                            }
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setImageResource(R.drawable.red_circle)
                }

                //InputLayout que vai conter o InputEditText do nome
                val nameInputLayout = TextInputLayout(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins(3, 0, 0, 0) // Set margins
                    }
                }

                //InputEditText do nome
                val nameEditText = TextInputEditText(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        150.dpToPx(context),
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f) // Example font size
                    setTextColor(ContextCompat.getColor(context, R.color.basil_green))
                    typeface = ResourcesCompat.getFont(context, R.font.roboto)
                    setHintTextColor(ContextCompat.getColor(context, R.color.black))
                    setLineSpacing(0f, 0.7f)
                    background = ContextCompat.getDrawable(context, R.drawable.orange_background)

                    setPadding(8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context)) // Adjust as necessary

                    //Um id único é gerado automaticamente e adicionado à lista de IDs
                    id = View.generateViewId() //Generates a new unic ID
                    ingIds2.add(id)

                    //Caso o layout esteja selecionado ou tenha alguma coisa escrita pelo user este deixa de ter hint
                    //Caso volte a estar vazio e sem estar selecionado a hint volta a aparecer
                    setOnFocusChangeListener{ _, hasFocus ->
                        if (hasFocus) {

                            nameInputLayout.hint = null
                        } else {
                            if (text.isNullOrEmpty()) {
                                nameInputLayout.hint = "Name"
                            }
                        }
                    }
                }
                //Coloca o nome original do ingrediente no InputLayout
                nameEditText.setText(ingList[i])
                i += 1

                //Image que aparece antes da quantidade
                val imageView2 = ImageView(this).apply {
                    layoutParams =
                        LinearLayout.LayoutParams(15.dpToPx(context), 10.dpToPx(context))
                            .apply {
                                setMargins(5, 0, 0, 0) // Set margins
                            }
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setImageResource(R.drawable.red_circle)
                }

                //InputLayout que vai conter o InputEditText da quantidade
                val qtdInputLayout = TextInputLayout(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins(3, 0, 0, 0) // Set margins
                    }
                }

                //InputEditText da quantidadde
                val qtdEditText = TextInputEditText(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        100.dpToPx(context),
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f) // Example font size
                    setTextColor(ContextCompat.getColor(context, R.color.basil_green))
                    typeface = ResourcesCompat.getFont(context, R.font.roboto)
                    setHintTextColor(ContextCompat.getColor(context, R.color.black))
                    setLineSpacing(0f, 0.7f)
                    background = ContextCompat.getDrawable(context, R.drawable.orange_background)

                    setPadding(8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context)) // Adjust as necessary

                    //Um id único é gerado automaticamente e adicionado à lista de IDs
                    id = View.generateViewId() //Generates a new unic ID
                    ingIds2.add(id)

                    //Caso o layout esteja selecionado ou tenha alguma coisa escrita pelo user este deixa de ter hint
                    //Caso volte a estar vazio e sem estar selecionado a hint volta a aparecer
                    setOnFocusChangeListener{ _, hasFocus ->
                        if (hasFocus) {
                            qtdInputLayout.hint = null
                        } else {
                            if (text.isNullOrEmpty()) {
                                qtdInputLayout.hint = "Quantity"
                            }
                        }
                    }
                }
                //Coloca a quantidade original do ingrediente no InputLayout
                qtdEditText.setText(ingList[i])
                i += 1

                //deleteIngBtn clicado -> remover os ids dos inputs do array e apagar o LinearLayout no qual o botão está
                deleteIngBtn.setOnClickListener()
                {
                    //Remover os Ids do Array
                    ingIds2.remove(nameEditText.id)
                    ingIds2.remove(qtdEditText.id)

                    //Remover o LinearLayout do Parent Layout
                    ingListLayout.removeView(ingredientLayout)

                    //Debug
                    Log.d("Lista de IDs", ingIds2.toString())
                }



                //Adicionar os TextInputEditText aos respectivos TextInputLayout
                nameInputLayout.addView(nameEditText)
                qtdInputLayout.addView(qtdEditText)

                //Adicionar elementos criados ao LinearLayout
                ingredientLayout.addView(deleteIngBtn)
                ingredientLayout.addView(imageView1)
                ingredientLayout.addView(nameInputLayout)
                ingredientLayout.addView(imageView2)
                ingredientLayout.addView(qtdInputLayout)

                //Adicionar LinearLayout ao Parent Layout
                ingListLayout.addView(ingredientLayout)
            }
        }
    }

    //Recebe o linearLayout onde deve adicionar as novas linhas com inputs para os ingredientes
    private fun addIngredient(inglistLayout : LinearLayout)
    {
        //LinearLayout Horizontal que vai conter os elementos
        val ingredientLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        //Botão para apagar ingredientes
        val deleteIngBtn = ImageButton(this).apply {
            layoutParams = LinearLayout.LayoutParams(45.dpToPx(context), 45.dpToPx(context)).apply {
                gravity = Gravity.END
            }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageResource(R.drawable.delete)

            val outValue = TypedValue()
            context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, outValue, true)
            setBackgroundResource(outValue.resourceId)
        }

        //Image que aparece antes do nome
        val imageView1 = ImageView(this).apply {
            layoutParams =
                LinearLayout.LayoutParams(15.dpToPx(context), 10.dpToPx(context)).apply {
                    setMargins(30, 0, 0, 0) // Set margins
                }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageResource(R.drawable.red_circle)
        }

        //InputLayout que vai conter o InputEditText do nome
        val nameInputLayout = TextInputLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(3, 0, 0, 0) // Set margins
            }
        }

        //InputEditText do nome
        val nameEditText = TextInputEditText(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                150.dpToPx(context),
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            hint = "Name"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f) // Example font size
            setTextColor(ContextCompat.getColor(context, R.color.basil_green))
            typeface = ResourcesCompat.getFont(context, R.font.roboto)
            setHintTextColor(ContextCompat.getColor(context, R.color.black))
            setLineSpacing(0f, 0.7f)
            background = ContextCompat.getDrawable(context, R.drawable.orange_background)

            setPadding(8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context)) // Adjust as necessary

            //Um id único é gerado automaticamente e adicionado à lista de IDs
            id = View.generateViewId()
            ingIds2.add(id)

            //Caso o layout esteja selecionado ou tenha alguma coisa escrita pelo user este deixa de ter hint
            //Caso volte a estar vazio e sem estar selecionado a hint volta a aparecer
            setOnFocusChangeListener{ _, hasFocus ->
                if (hasFocus) {
                    // Hide hint when the field is focused
                    nameInputLayout.hint = null
                } else {
                    // Show hint only if field is empty and not focused
                    if (text.isNullOrEmpty()) {
                        nameInputLayout.hint = "Name"
                    }
                }
            }
        }

        //Image que aparece antes da quantidade
        val imageView2 = ImageView(this).apply {
            layoutParams =
                LinearLayout.LayoutParams(15.dpToPx(context), 10.dpToPx(context)).apply {
                    setMargins(5, 0, 0, 0) // Set margins
                }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageResource(R.drawable.red_circle)
        }

        //InputLayout que vai conter o InputEditText da quantidade
        val qtdInputLayout = TextInputLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(3, 0, 0, 0) // Set margins
            }
        }

        //InputEditText da quantidadde
        val qtdEditText = TextInputEditText(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                100.dpToPx(context),
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            hint = "Quantity"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f) // Example font size
            setTextColor(ContextCompat.getColor(context, R.color.basil_green))
            typeface = ResourcesCompat.getFont(context, R.font.roboto)
            setHintTextColor(ContextCompat.getColor(context, R.color.black))
            setLineSpacing(0f, 0.7f)
            background = ContextCompat.getDrawable(context, R.drawable.orange_background)

            setPadding(8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context)) // Adjust as necessary

            //Um id único é gerado automaticamente e adicionado à lista de IDs
            id = View.generateViewId()
            ingIds2.add(id)

            //Caso o layout esteja selecionado ou tenha alguma coisa escrita pelo user este deixa de ter hint
            //Caso volte a estar vazio e sem estar selecionado a hint volta a aparecer
            setOnFocusChangeListener{ _, hasFocus ->
                if (hasFocus) {
                    qtdInputLayout.hint = null
                } else {
                    if (text.isNullOrEmpty()) {
                        qtdInputLayout.hint = "Quantity"
                    }
                }
            }
        }

        //deleteIngBtn clicado -> remover os ids dos inputs do array e apagar o LinearLayout no qual o botão está
        deleteIngBtn.setOnClickListener()
        {
            //Remover os Ids do Array
            ingIds2.remove(nameEditText.id)
            ingIds2.remove(qtdEditText.id)

            //Remover o LinearLayout do Parent Layout
            inglistLayout.removeView(ingredientLayout)

            //Debug
            Log.d("Lista de IDs", ingIds2.toString())
        }

        //Debug
        Log.d("Lista de IDs", ingIds2.toString())

        //Adicionar os TextInputEditText aos respectivos TextInputLayout
        nameInputLayout.addView(nameEditText)
        qtdInputLayout.addView(qtdEditText)

        //Adicionar elementos criados ao LinearLayout
        ingredientLayout.addView(deleteIngBtn)
        ingredientLayout.addView(imageView1)
        ingredientLayout.addView(nameInputLayout)
        ingredientLayout.addView(imageView2)
        ingredientLayout.addView(qtdInputLayout)

        //Adicionar LinearLayout ao Parent Layout
        inglistLayout.addView(ingredientLayout)
    }

    //Recebe os novos parâmetros da receita e atualiza esta na Base de Dados
    //Utiliza "suspend" para poder ser chamada fora a thread principal e garantir que o que vem depois d sua chamada apenas é executado depois de esta terminar
    private suspend fun updateRecipe(rId : Int, nameInput: TextInputEditText, meatCheckBox : CheckBox, fishCheckBox: CheckBox, vegetarianCheckBox: CheckBox, instructionsInput: TextInputEditText)
    {
        //Verifica qual o tipo de receita selecionado pelo utilizador
        val t = when {
            meatCheckBox.isChecked -> 1
            fishCheckBox.isChecked -> 2
            vegetarianCheckBox.isChecked -> 3
            else -> 0
        }

        //Percorre a lista de Ids dos ingredientes para acessar os respectivos inputs e guardálos numa unica string, separando cada um deles com ";"
        var ingString = ""
        for (id in ingIds2)
        {
            val textInput = findViewById<TextInputEditText>(id)
            textInput?.let {
                val text = it.text.toString()

                if (ingString.isNotEmpty()) {
                    ingString += ";"
                }
                ingString += text
            }
        }

        //Referência à Base de Dados e ao DAO
        val db = Room.databaseBuilder(
            applicationContext,
            ReceitasDatabase::class.java, "database_receitas"
        ).build()
        val receitasDao = db.receitasDao()

        //Querry à Base de Dados da receita que vai ser atualizada, com o Id especificado
        var recipeToUpdate = receitasDao.getById(rId)

        //Muda os valores da receita
        recipeToUpdate.nome = nameInput.text.toString()
        recipeToUpdate.tipo = t
        recipeToUpdate.ingredientes = ingString
        recipeToUpdate.instrucoes = instructionsInput.text.toString()

        //Atualiza a receita na base de dados
        receitasDao.updateRecipe(recipeToUpdate)
    }
}