package com.example.pocektchefproj
import androidx.room.*

@Entity(tableName = "Receitas")
data class Receita(
    @PrimaryKey(autoGenerate = true) val id : Int = 0,
    var nome: String,
    var tipo: Int?,
    var ingredientes: String?,
    var instrucoes: String?
)

@Dao
interface ReceitasDao {
    @Query("SELECT * FROM Receitas")
    fun getAllReceitas(): List<Receita>

    @Query("SELECT * FROM Receitas WHERE tipo = :tipoValue")
    fun getAllByTipo(tipoValue: Int): List<Receita>

    @Query("SELECT * FROM Receitas WHERE nome = :nomeReceita")
    fun findByName(nomeReceita: String): Receita

    @Query("SELECT * FROM Receitas WHERE id = :idReceita")
    fun getById(idReceita: Int): Receita

    @Insert
    fun insertReceita(receita: Receita)

    @Query("DELETE FROM Receitas WHERE id = :idReceita")
    fun deleteById(idReceita: Int)

    @Query("DELETE FROM Receitas")
    fun deleteAll()

    @Update
    suspend fun updateRecipe(receita: Receita)
}

@Database(entities = [Receita::class], version = 1)
abstract class ReceitasDatabase : RoomDatabase() {
    abstract fun receitasDao(): ReceitasDao
}