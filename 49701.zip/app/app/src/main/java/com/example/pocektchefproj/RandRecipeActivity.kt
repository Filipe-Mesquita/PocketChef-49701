package com.example.pocektchefproj

import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.room.Room
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class RandRecipeActivity : AppCompatActivity() {
    //Na criação da Activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_recipe)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Armazenamento dos valores passados por Intent
        //Como esta activity pode ser acessada a partir de duas outras activities diferentes o prevPage serve para saber qual é a ativiadde predecessora
        val prevPage = intent.getStringExtra("PREV_PAGE")
        val foodID = intent.getIntExtra("FOOD_ID", 0)
        val foodType = intent.getIntExtra("FOOD_TYPE", 1)
        val foodTitle = intent.getStringExtra("FOOD_TITLE")
        val foodIngs = intent.getStringExtra("FOOD_INGS")
        val foodInst = intent.getStringExtra("FOOD_INST")

        //Referências aos elementos do .xml
        val topBarLayout = findViewById<LinearLayout>(R.id.topBarLT)
        val backBtn2 = findViewById<ImageButton>(R.id.backBTN2)
        val foodTypeImg = findViewById<ImageView>(R.id.foodTypeIMG)
        val foodTitleText = findViewById<TextView>(R.id.recipeNameTXT2)
        val recipeIngLayout = findViewById<LinearLayout>(R.id.recipeIngLT)
        val foodInstText = findViewById<TextView>(R.id.recipeInstTXT)

        //Dependeno do tipo da receita é apresentada uma imagem diferente
        when (foodType)
        {
            1 -> foodTypeImg.setImageResource(R.drawable.meat) // Set image resource from the recipe
            2 -> foodTypeImg.setImageResource(R.drawable.fish) // Set image resource from the recipe
            3 -> foodTypeImg.setImageResource(R.drawable.vegetables) // Set image resource from the recipe
        }

        //SetText do Nome da receita
        foodTitleText.text = foodTitle

        //backBtn2 clicado -> troca de activity
        backBtn2.setOnClickListener()
        {
            //Consoante a página anterior a APP troca para essa página
            val intentPagina = when(prevPage)
            {
                "list" -> Intent(this, RecipeListActivity::class.java)
                "type" -> Intent(this, FoodTypeActivity::class.java)
                else -> null
            }
            intentPagina?.let {
                startActivity(it)

                //Termina a activity atual
                finish()
            }
        }

        //Split da String com ingredientes que vei da Base de Dados
        //Isto separa os ingreientes e as respetivas quantidades em strings separadas numa List<String>
        //O formato da lista é - ["ing1","qtding1","ing2","qtdIng2","ing3",...]
        val foodIngsList = foodIngs?.split(";")
        // DEBUG
        //
        // if(foodIngs != null) {
        //    Log.d("Ingre", foodIngs)
        //}
        //if(foodIngsList != null) {
        //    for (x in foodIngsList) {
        //        Log.d("Ingrediente/Quantidade", "$x\n")
        //    }
        //}
        populateIngredients(foodIngsList, recipeIngLayout)

        //SetText das instruções da receita
        foodInstText.text = foodInst

        //Caso a página anterior seja a lista de receitas são criados também botões de eliminar e editar a receita
        if (prevPage == "list")
        {
            creatDeleteAndEditButton(topBarLayout, foodID, prevPage, foodType, foodTitle, foodIngs, foodInst)
        }
    }

    //Recebe uma lista com todas os ingredientes e respetivas quantidades e coloca cada um no Parent LinearLayout dado
    private fun populateIngredients(ingList: List<String>?, ingLayout: LinearLayout) {
        var i = 0
        //Garante que a lista de ingredientes não é nula
        if (ingList != null) {
            for (n in 0 until ingList.size / 2) {       // apenas iteramos n/2 vezes, sendo n o tamanho da lista de ingredients porque a cada iteração vamos acessar dois elementos da lista

                //LinearLayout Horizontal que vai conter os elementos
                val ingredientLayout = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                }

                //Image que aparece antes do nome
                val imageView1 = ImageView(this).apply {
                    layoutParams =
                        LinearLayout.LayoutParams(15.dpToPx(context), 10.dpToPx(context))
                            .apply {
                                setMargins(30, 0, 0, 0) // Set margins
                            }
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setImageResource(R.drawable.red_circle)
                }

                //TextView com o nome do ingrediente
                val ingNameTextView = TextView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        150.dpToPx(context),
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    text = ingList[i]
                    textSize = 17f // Example font size
                    setTextColor(ContextCompat.getColor(context, R.color.light_orange))
                    typeface = ResourcesCompat.getFont(context, R.font.roboto)
                }

                i += 1

                //Image que aparece antes da quantidade
                val imageView2 = ImageView(this).apply {
                    layoutParams =
                        LinearLayout.LayoutParams(15.dpToPx(context), 10.dpToPx(context))
                            .apply {
                                setMargins(5, 0, 0, 0) // Set margins
                            }
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setImageResource(R.drawable.red_circle)
                }

                //TextView com a quantidade do ingrediente
                val ingQtdTextView = TextView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        100.dpToPx(context),
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    text = ingList[i]
                    textSize = 17f // Example font size
                    setTextColor(ContextCompat.getColor(context, R.color.light_orange))
                    typeface = ResourcesCompat.getFont(context, R.font.roboto)
                }
                i += 1

                //Adicionar elementos criados ao LinearLayout
                ingredientLayout.addView(imageView1)
                ingredientLayout.addView(ingNameTextView)
                ingredientLayout.addView(imageView2)
                ingredientLayout.addView(ingQtdTextView)

                //Adicionar LinearLayout ao Parent Layout
                ingLayout.addView(ingredientLayout)
            }
        }
    }


    //Recebe O LinearLayout onde deve colocar os botões e os parâmetros da receita necessários para eliminar ou editar a receita
    private fun creatDeleteAndEditButton(topBarLayout : LinearLayout, rID : Int, prevPage : String, foodType : Int, foodTitle : String?, foodIngs : String?, foodInst : String?)
    {
        //Botão de delete
        val deleteButton = ImageButton(this).apply {
            layoutParams = LinearLayout.LayoutParams(75.dpToPx(context), 65.dpToPx(context)).apply {
                gravity = Gravity.END
            }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageResource(R.drawable.delete) // Set your drawable resource here

            // Set selectableItemBackgroundBorderless as background
            val outValue = TypedValue()
            context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, outValue, true)
            setBackgroundResource(outValue.resourceId)
        }

        //deleteButton clicado -> confirmar se o User quer eliminar a receita e caso seja positivo, eliminá-la e trocar de Activity
        deleteButton.setOnClickListener()
        {
            //Cria um Alert Dialog com a pergunta de confirmação
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Delete Recipe")
            builder.setMessage("Are you sure you want to delete this recipe? This action cannot be undone.")

            //Caso a resposta seja sim
            builder.setPositiveButton("Yes") { dialog, _ ->
                //cria uma corrotina
                CoroutineScope(Dispatchers.IO).launch{

                    deleteRecipe(rID)

                    //Passa a executar na main Thread
                    withContext(Dispatchers.Main)
                    {
                        val intent = Intent(this@RandRecipeActivity, RecipeListActivity::class.java)
                        startActivity(intent)

                        //Termina a activity atual
                        finish()
                    }
                }
                //Cria um toast
                Toast.makeText(this, "Recipe deleted", Toast.LENGTH_SHORT).show()
                //Fecha o Alert Dialog
                dialog.dismiss()
            }

            //Caso a resposta seja não
            builder.setNegativeButton("No") { dialog, _ ->
                //Fecha o Alert Dialog
                dialog.dismiss()
            }

            // Display do alert dialog
            builder.show()
        }

        //Botão de edit
        val editButton = ImageButton(this).apply {
            layoutParams = LinearLayout.LayoutParams(75.dpToPx(context), 65.dpToPx(context)).apply {
                gravity = Gravity.END
                marginEnd = 20.dpToPx(context)
            }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageResource(R.drawable.edit) // Set your drawable resource here

            // Set selectableItemBackgroundBorderless as background
            val outValue = TypedValue()
            context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, outValue, true)
            setBackgroundResource(outValue.resourceId)
        }

        //editButton clicado -> trocar de Activity passando as informações necessárias por Intent
        editButton.setOnClickListener()
        {
            val intent = Intent(this, editRecipeActivity::class.java)
            intent.putExtra("PREV_PAGE", prevPage)
            intent.putExtra("FOOD_ID", rID)
            intent.putExtra("FOOD_TYPE", foodType)
            intent.putExtra("FOOD_TITLE", foodTitle)
            intent.putExtra("FOOD_INGS", foodIngs)
            intent.putExtra("FOOD_INST", foodInst)
            startActivity(intent)
            finish()
        }

        //Adicionar elementos criados ao LinearLayout
        topBarLayout.addView(deleteButton)
        topBarLayout.addView(editButton)
    }

    //Recebe o Id a receita que deve apagar e elimina-a da Base de Dados
    private suspend fun deleteRecipe(rID : Int)
    {
        //Referência à Base de Dados e ao DAO
        val db = Room.databaseBuilder(
            applicationContext,
            ReceitasDatabase::class.java, "database_receitas"
        ).build()
        val receitasDao = db.receitasDao()

        //Querry à Base de Dados para eliminar a receita com o Id especificado
        receitasDao.deleteById(rID)
    }
}