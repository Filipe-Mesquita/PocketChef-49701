package com.example.pocektchefproj

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.room.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// Pass context to access resources
fun Int.dpToPx(context: Context): Int = (this * context.resources.displayMetrics.density).toInt()


class RecipeListActivity : AppCompatActivity() {
    //Na criação da Activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_recipe_list)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Referências aos elementos do .xml
        val recipeSLayout = findViewById<LinearLayout>(R.id.recipesLAYOUT)
        val backBtn3 = findViewById<ImageButton>(R.id.backBTN3)
        val addBtn = findViewById<ImageButton>(R.id.addBTN)

        //backBtn3 clicado -> troca de activity
        backBtn3.setOnClickListener()
        {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            //Termina a activity atual
            finish()
        }

        //addBtn clicado -> troca de activity
        addBtn.setOnClickListener()
        {
            val intent = Intent(this, createRecipeActivity::class.java)
            startActivity(intent)

            //Termina a activity atual
            finish()
        }

        //cria uma corrotina
        CoroutineScope(Dispatchers.IO).launch {
            //Referência à Base de Dados e ao DAO
            val db = Room.databaseBuilder(
                applicationContext,
                ReceitasDatabase::class.java, "database_receitas"
            ).build()
            val receitasDao = db.receitasDao()

            //Querry à Base de Dados de todas as receitas
            val receitasList = receitasDao.getAllReceitas()


            //Passa a executar na main Thread
            launch(Dispatchers.Main) {
                populateRecipes(recipeSLayout, receitasList)
            }
        }
    }

    //Recebe uma lista com todas as receitas e coloca cada uma no Parent LinearLayout dado
    private fun populateRecipes(recipeSLayout: LinearLayout, receitasList: List<Receita>) {
        if(receitasList.isNotEmpty())
        {
            for (r in receitasList) {

                //LinearLayout Horizontal que vai conter os elementos
                val recipeLayout = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins(0, 25, 0, 0) // Set margins
                    }
                    background = ContextCompat.getDrawable(context, R.drawable.green_background)

                    // Make the layout clickable
                    isClickable = true
                    isFocusable = true
                }

                //Image correspondente com o tipo da receita
                val imageView = ImageView(this).apply {
                    layoutParams =
                        LinearLayout.LayoutParams(110.dpToPx(context), 110.dpToPx(context)).apply {
                            setMargins(10, 0, 0, 0) // Set margins
                        }
                    scaleType = ImageView.ScaleType.FIT_CENTER

                    when (r.tipo) {
                        1 -> setImageResource(R.drawable.meat) // Set image resource from the recipe
                        2 -> setImageResource(R.drawable.fish) // Set image resource from the recipe
                        3 -> setImageResource(R.drawable.vegetables) // Set image resource from the recipe
                    }
                }

                //TextView com o nome da Receita
                val textView = TextView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        200.dpToPx(context),
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins(10, 0, 0, 0) // Set margins
                    }
                    text = r.nome
                    textSize = 20f
                    setTextColor(ContextCompat.getColor(context, R.color.light_orange))
                    typeface = ResourcesCompat.getFont(context, R.font.rock_salt)

                    //Sombra do texto
                    setShadowLayer(
                        1.5f,
                        5f,
                        5f,
                        ContextCompat.getColor(context, R.color.black)  // Shadow color
                    )
                }

                //Adicionar elementos criados ao LinearLayout
                recipeLayout.addView(imageView)
                recipeLayout.addView(textView)

                //recipelayout clicado -> trocar de activity passando os parâmetros da receita selecionada
                recipeLayout.setOnClickListener {
                    val intent = Intent(this, RandRecipeActivity::class.java)
                    intent.putExtra("PREV_PAGE", "list")
                    intent.putExtra("FOOD_ID", r.id)
                    intent.putExtra("FOOD_TITLE", r.nome)
                    intent.putExtra("FOOD_TYPE", r.tipo)
                    intent.putExtra("FOOD_INGS", r.ingredientes)
                    intent.putExtra("FOOD_INST", r.instrucoes)
                    startActivity(intent)

                    //terminar activity
                    finish()
                }

                //Adicionar LinearLayout ao Parent Layout
                recipeSLayout.addView(recipeLayout)
            }
        }
        else //caso não haja receitas na Base de Dados
        {
            //textView com mensagem
            val noRecipestextView = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    200.dpToPx(context),
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(10, 0, 0, 0) // Set margins
                }
                text = "PLEASE CREATE\nA RECIPE"
                textSize = 17f
                setTextColor(ContextCompat.getColor(context, R.color.red))
                typeface = ResourcesCompat.getFont(context, R.font.rock_salt)
                gravity = Gravity.CENTER_HORIZONTAL

                //Sombra do texto
                setShadowLayer(
                    1.5f,  // Radius (how much the shadow should be blurred)
                    5f,    // Dx (horizontal offset)
                    5f,    // Dy (vertical offset)
                    ContextCompat.getColor(context, R.color.black)  // Shadow color
                )
            }

            //Adicionar TextView ao Parent Layout
            recipeSLayout.addView(noRecipestextView)
        }
    }
}

