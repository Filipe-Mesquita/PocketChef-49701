package com.example.pocektchefproj

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import android.util.TypedValue
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import android.view.View
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.room.Room
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

//Array auxiliar para guardar os Ids dos layouts do nome e quantidade de cada Ingradiente
var ingIds = arrayListOf<Int>()

class createRecipeActivity : AppCompatActivity() {
    //Na criação da Activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_create_recipe)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Referências aos elementos do .xml
        val backBtn4 = findViewById<ImageButton>(R.id.backBTN4)
        val meatCheckBox = findViewById<CheckBox>(R.id.meatCheckBox)
        val fishCheckBox = findViewById<CheckBox>(R.id.fishCheckBox)
        val vegetarianCheckBox = findViewById<CheckBox>(R.id.vegetarianCheckBox)
        val nameInputLayout = findViewById<TextInputLayout>(R.id.nameTextInputLayout)
        val nameInput = findViewById<TextInputEditText>(R.id.nameTextInput)
        val ingList = findViewById<LinearLayout>(R.id.ingListLayout)
        val addIngBtn = findViewById<ImageButton>(R.id.addIngBTN)
        val instructionsInputLayout = findViewById<TextInputLayout>(R.id.instructionsTextInputLayout)
        val instructionsInput = findViewById<TextInputEditText>(R.id.instructionsTextInput)
        val createBtn = findViewById<Button>(R.id.createBTN)

        //backBtn4 clicado -> troca de activity
        backBtn4.setOnClickListener()
        {
            val intent = Intent(this, RecipeListActivity::class.java)
            startActivity(intent)

            //Termina a activity atual
            finish()
        }


        //Apenas uma CheckBox pode estar "checked"
        //Caso uma nova seja "checked" a antiga deixa de estar
        meatCheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                fishCheckBox.isChecked = false
                vegetarianCheckBox.isChecked = false
            }
        }
        fishCheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                meatCheckBox.isChecked = false
                vegetarianCheckBox.isChecked = false
            }
        }
        vegetarianCheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                meatCheckBox.isChecked = false
                fishCheckBox.isChecked = false
            }
        }

        //Coloca uma hit no layout de Input do nome da receita
        nameInputLayout.hint = "Write here the recipe's name"

        //Caso o layout esteja selecionado ou tenha alguma coisa escrita  pelo user este deixa de ter hint
        //Caso volte a estar vazio e sem estar selecionado a hint volta a aparecer
        nameInput.setOnFocusChangeListener{ _, hasFocus ->
            if (hasFocus) {
                nameInputLayout.hint = null
            } else {
                if (nameInput.text.isNullOrEmpty()) {
                    nameInputLayout.hint = "Write here the recipe's name"
                }
            }
        }

        //Coloca uma hit no layout de Input das instruções da receita
        instructionsInputLayout.hint = "Write here the recipe's instructions"

        //Caso o layout esteja selecionado ou tenha alguma coisa escrita  pelo user este deixa de ter hint
        //Caso volte a estar vazio e sem estar selecionado a hint volta a aparecer
        instructionsInput.setOnFocusChangeListener{ _, hasFocus ->
            if (hasFocus) {
                instructionsInputLayout.hint = null
            } else {
                if (instructionsInput.text.isNullOrEmpty()) {
                    instructionsInputLayout.hint = "Write here the recipe's instructions"
                }
            }
        }

        //addIngBtn clicado -> Adicionar nova linha de input de ingrediente
        addIngBtn.setOnClickListener()
        {
            addIngredient(ingList)
        }

        //createBtn clicado -> verificar se todos os campos estão preenchidos, caso estejam chama a dunção que adiciona a receita à Base de Dados e troca de Activity, caso contrário aparece um toast com uma mensagem de aviso
        createBtn.setOnClickListener()
        {
            //cria uma corrotina
            CoroutineScope(Dispatchers.IO).launch{
                if(nameInput == null || (!meatCheckBox.isChecked && !fishCheckBox.isChecked &&!vegetarianCheckBox.isChecked) || instructionsInput == null || ingIds.isEmpty())      //Caso existam campos vazios
                {
                    //Passa a executar na main Thread
                    withContext(Dispatchers.Main)
                    {
                        //Cria um toast
                        Toast.makeText(this@createRecipeActivity, "Please fill every field", Toast.LENGTH_SHORT).show()
                    }
                }
                else
                {
                    addRecipe(nameInput, meatCheckBox, fishCheckBox, vegetarianCheckBox, instructionsInput)

                    //Passa a executar na main Thread
                    withContext(Dispatchers.Main)
                    {
                        //Cria um toast
                        Toast.makeText(this@createRecipeActivity, "Recipe created successfully", Toast.LENGTH_SHORT).show()

                        val intent = Intent(this@createRecipeActivity, RecipeListActivity::class.java)
                        startActivity(intent)

                        //Termina a activity atual
                        finish()
                    }
                }
            }
        }
    }

    //Recebe o linearLayout onde deve adicionar as novas linhas com inputs para os ingredientes
    private fun addIngredient(inglist : LinearLayout)
    {
        //LinearLayout Horizontal que vai conter os elementos
        val ingredientLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
                )
        }

        //Botão para apagar ingredientes
        val deleteIngBtn = ImageButton(this).apply {
            layoutParams = LinearLayout.LayoutParams(45.dpToPx(context), 45.dpToPx(context)).apply {
                gravity = Gravity.END
            }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageResource(R.drawable.delete)


            val outValue = TypedValue()
            context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, outValue, true)
            setBackgroundResource(outValue.resourceId)
        }

        //Image que aparece antes do nome
        val imageView1 = ImageView(this).apply {
            layoutParams =
                LinearLayout.LayoutParams(15.dpToPx(context), 10.dpToPx(context)).apply {
                    setMargins(0, 0, 0, 0) // Set margins
                }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageResource(R.drawable.red_circle)
        }

        //InputLayout que vai conter o InputEditText do nome
        val nameInputLayout = TextInputLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(3, 0, 0, 0) // Set margins
            }
        }

        //InputEditText do nome
        val nameEditText = TextInputEditText(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                150.dpToPx(context),
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            hint = "Name"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f) // Example font size
            setTextColor(ContextCompat.getColor(context, R.color.basil_green))
            typeface = ResourcesCompat.getFont(context, R.font.roboto)
            setHintTextColor(ContextCompat.getColor(context, R.color.black))
            setLineSpacing(0f, 0.7f)
            background = ContextCompat.getDrawable(context, R.drawable.orange_background)

            setPadding(8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context)) // Adjust as necessary

            //Um id único é gerado automaticamente e adicionado à lista de IDs
            id = View.generateViewId()
            ingIds.add(id)

            //Caso o layout esteja selecionado ou tenha alguma coisa escrita pelo user este deixa de ter hint
            //Caso volte a estar vazio e sem estar selecionado a hint volta a aparecer
            setOnFocusChangeListener{ _, hasFocus ->
                if (hasFocus) {
                    nameInputLayout.hint = null
                } else {
                    if (text.isNullOrEmpty()) {
                        nameInputLayout.hint = "Name"
                    }
                }
            }
        }

        //Image que aparece antes da quantidade
        val imageView2 = ImageView(this).apply {
            layoutParams =
                LinearLayout.LayoutParams(15.dpToPx(context), 10.dpToPx(context)).apply {
                    setMargins(5, 0, 0, 0) // Set margins
                }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageResource(R.drawable.red_circle)
        }

        //InputLayout que vai conter o InputEditText da quantidade
        val qtdInputLayout = TextInputLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(3, 0, 0, 0) // Set margins
            }
        }

        //InputEditText da quantidadde
        val qtdEditText = TextInputEditText(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                100.dpToPx(context),
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            hint = "Quantity"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f) // Example font size
            setTextColor(ContextCompat.getColor(context, R.color.basil_green))
            typeface = ResourcesCompat.getFont(context, R.font.roboto)
            setHintTextColor(ContextCompat.getColor(context, R.color.black))
            setLineSpacing(0f, 0.7f)
            background = ContextCompat.getDrawable(context, R.drawable.orange_background)

            setPadding(8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context), 8.dpToPx(context)) // Adjust as necessary

            //Um id único é gerado automaticamente e adicionado à lista de IDs
            id = View.generateViewId()
            ingIds.add(id)

            //Caso o layout esteja selecionado ou tenha alguma coisa escrita pelo user este deixa de ter hint
            //Caso volte a estar vazio e sem estar selecionado a hint volta a aparecer
            setOnFocusChangeListener{ _, hasFocus ->
                if (hasFocus) {
                    qtdInputLayout.hint = null
                } else {
                    if (text.isNullOrEmpty()) {
                        qtdInputLayout.hint = "Quantity"
                    }
                }
            }
        }

        //deleteIngBtn clicado -> remover os ids dos inputs do array e apagar o LinearLayout no qual o botão está
        deleteIngBtn.setOnClickListener()
        {
            //Remover os Ids do Array
            ingIds.remove(nameEditText.id)
            ingIds.remove(qtdEditText.id)

            //Remover o LinearLayout do Parent Layout
            inglist.removeView(ingredientLayout)

            //Debug
            Log.d("Lista de IDs", ingIds.toString())
        }

        //Debug
        Log.d("Lista de IDs", ingIds.toString())

        //Adicionar os TextInputEditText aos respectivos TextInputLayout
        nameInputLayout.addView(nameEditText)
        qtdInputLayout.addView(qtdEditText)

        //Adicionar elementos criados ao LinearLayout
        ingredientLayout.addView(deleteIngBtn)
        ingredientLayout.addView(imageView1)
        ingredientLayout.addView(nameInputLayout)
        ingredientLayout.addView(imageView2)
        ingredientLayout.addView(qtdInputLayout)

        //Adicionar LinearLayout ao Parent Layout
        inglist.addView(ingredientLayout)
    }

    //Recebe os parâmetros da nova receita e adiciona esta à Base de Dados
    //Utiliza "suspend" para poder ser chamada fora a thread principal e garantir que o que vem depois d sua chamada apenas é executado depois de esta terminar
    private suspend fun addRecipe(nameInput: TextInputEditText, meatCheckBox : CheckBox, fishCheckBox: CheckBox, vegetarianCheckBox: CheckBox, instructionsInput: TextInputEditText)
    {
        //Verifica qual o tipo de receita selecionado pelo utilizador
        val t = when {
            meatCheckBox.isChecked -> 1
            fishCheckBox.isChecked -> 2
            vegetarianCheckBox.isChecked -> 3
            else -> 0
        }

        //Percorre a lista de Ids dos ingredientes para acessar os respectivos inputs e guardálos numa unica string, separando cada um deles com ";"
        var ingString = ""
        for (id in ingIds)
        {
            val textInput = findViewById<TextInputEditText>(id)
            textInput?.let {
                val text = it.text.toString()

                if (ingString.isNotEmpty()) {
                    ingString += ";"
                }
                ingString += text
            }
        }

        //Referência à Base de Dados e ao DAO
        val db = Room.databaseBuilder(
            applicationContext,
            ReceitasDatabase::class.java, "database_receitas"
        ).build()
        val receitasDao = db.receitasDao()

        //Cria uma nova receita
        val novaReceita = Receita(nome = nameInput.text.toString(), tipo = t, ingredientes = ingString, instrucoes = instructionsInput.text.toString())
        //Adiciona-a à Base de Dados
        receitasDao.insertReceita(novaReceita)
    }
}