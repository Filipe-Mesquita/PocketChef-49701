package com.example.pocektchefproj

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    //Na criação da Activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Referências aos elementos do .xml
        val cookBtn = findViewById<Button>(R.id.cookBTN)
        val recipesBtn = findViewById<Button>(R.id.recipesBTN)

        //cookBtn clicado -> troca de activity
        cookBtn.setOnClickListener()
        {
            val intent = Intent(this, FoodTypeActivity::class.java)
            startActivity(intent)
        }

        //recipesBtn clicado -> troca de activity
        recipesBtn.setOnClickListener()
        {
            val intent = Intent(this, RecipeListActivity::class.java)
            startActivity(intent)
        }
    }
}