package com.example.pocektchefproj

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.room.Room
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random
import android.widget.Toast

class FoodTypeActivity : AppCompatActivity() {
    //Na criação da Activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_food_type)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.foodType)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Referências aos elementos do .xml
        val backBtn = findViewById<ImageButton>(R.id.backBTN1)
        val meatBtn = findViewById<ImageButton>(R.id.meatBTN)
        val fishBtn = findViewById<ImageButton>(R.id.fishBTN)
        val vegBtn = findViewById<ImageButton>(R.id.vegBTN)

        //backBtn clicado -> troca de activity
        backBtn.setOnClickListener()
        {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            //Termina a activity atual
            finish()
        }

        //meatBtn ou fishBtn ou vegBtn clicados -> querry à base de dados para obter
        //todas as receitas do tipo escolhido pelo utilizador -> uma aleatória é passada para a proxima activity
        meatBtn.setOnClickListener()
        {
            //cria uma corrotina
            CoroutineScope(Dispatchers.IO).launch {
                //Referência à Base de Dados e ao DAO
                val db = Room.databaseBuilder(
                    applicationContext,
                    ReceitasDatabase::class.java, "database_receitas"
                ).build()
                val receitasDao = db.receitasDao()

                //Querry à Base de Dados de todas as receitas de um tipo específico
                val rList = receitasDao.getAllByTipo(1)

                if(rList.isEmpty())
                {
                    //Passa a executar na main Thread
                    withContext(Dispatchers.Main)
                    {
                        //Cria um toast
                        Toast.makeText(this@FoodTypeActivity, "No meat recipes available", Toast.LENGTH_SHORT).show()
                    }
                }
                else
                {
                    //Seleciona uma receita aleatória
                    val randIndex = Random.nextInt(rList.size)
                    val r = rList[randIndex]

                    //Passa a executar na main Thread
                    withContext(Dispatchers.Main) {
                        val intent = Intent(this@FoodTypeActivity, RandRecipeActivity::class.java)

                        //Passa a receita escolhida por Intent
                        intent.putExtra("PREV_PAGE", "type")
                        intent.putExtra("FOOD_ID", r.id)
                        intent.putExtra("FOOD_TITLE", r.nome)
                        intent.putExtra("FOOD_TYPE", r.tipo)
                        intent.putExtra("FOOD_INGS", r.ingredientes)
                        intent.putExtra("FOOD_INST", r.instrucoes)
                        startActivity(intent)

                        //Termina a activity atual
                        finish()
                    }
                }
            }
        }
        fishBtn.setOnClickListener()
        {
            //cria uma corrotina
            CoroutineScope(Dispatchers.IO).launch {
                //cria uma referência à Base de Dados e ao DAO
                val db = Room.databaseBuilder(
                    applicationContext,
                    ReceitasDatabase::class.java, "database_receitas"
                ).build()
                val receitasDao = db.receitasDao()

                //Querry à Base de Dados de todas as receitas de um tipo específico
                val rList = receitasDao.getAllByTipo(2)

                if(rList.isEmpty())
                {
                    //Passa a executar na main Thread
                    withContext(Dispatchers.Main)
                    {
                        //Cria um toast
                        Toast.makeText(this@FoodTypeActivity, "No fish recipes available", Toast.LENGTH_SHORT).show()
                    }
                }
                else
                {
                    //Seleciona uma receita aleatória
                    val randIndex = Random.nextInt(rList.size)
                    val r = rList[randIndex]

                    //Passa a executar na main Thread
                    withContext(Dispatchers.Main) {
                        val intent = Intent(this@FoodTypeActivity, RandRecipeActivity::class.java)

                        //Passa a receita escolhida por Intent
                        intent.putExtra("PREV_PAGE", "type")
                        intent.putExtra("FOOD_ID", r.id)
                        intent.putExtra("FOOD_TITLE", r.nome)
                        intent.putExtra("FOOD_TYPE", r.tipo)
                        intent.putExtra("FOOD_INGS", r.ingredientes)
                        intent.putExtra("FOOD_INST", r.instrucoes)
                        startActivity(intent)

                        //Termina a activity atual
                        finish()
                    }
                }
            }
        }
        vegBtn.setOnClickListener()
        {
            //cria uma corrotina
            CoroutineScope(Dispatchers.IO).launch {
                //cria uma referência à Base de Dados e ao DAO
                val db = Room.databaseBuilder(
                    applicationContext,
                    ReceitasDatabase::class.java, "database_receitas"
                ).build()
                val receitasDao = db.receitasDao()

                //Querry à Base de Dados de todas as receitas de um tipo específico
                val rList = receitasDao.getAllByTipo(3)

                if(rList.isEmpty())
                {
                    //Passa a executar na main Thread
                    withContext(Dispatchers.Main)
                    {
                        //Cria um toast
                        Toast.makeText(this@FoodTypeActivity, "No vegetarian recipes available", Toast.LENGTH_SHORT).show()
                    }
                }
                else
                {
                    //Seleciona uma receita aleatória
                    val randIndex = Random.nextInt(rList.size)
                    val r = rList[randIndex]

                    //Passa a executar na main Thread
                    withContext(Dispatchers.Main) {
                        val intent = Intent(this@FoodTypeActivity, RandRecipeActivity::class.java)

                        //Passa a receita escolhida por Intent
                        intent.putExtra("PREV_PAGE", "type")
                        intent.putExtra("FOOD_ID", r.id)
                        intent.putExtra("FOOD_TITLE", r.nome)
                        intent.putExtra("FOOD_TYPE", r.tipo)
                        intent.putExtra("FOOD_INGS", r.ingredientes)
                        intent.putExtra("FOOD_INST", r.instrucoes)
                        startActivity(intent)

                        //Termina a activity atual
                        finish()
                    }
                }
            }
        }
    }
}